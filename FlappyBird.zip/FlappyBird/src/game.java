import javax.swing.*;
import javax.swing.event.MouseInputListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import java.util.Random;

@SuppressWarnings("serial")
public class game extends JPanel implements ActionListener,KeyListener {
	
	static JFrame frame = new JFrame("FLY FLY BIRD (press enter to start/restart) /tab for background change");
	
    private int birdY = 250; // Initial Y position of the block
    private int blockVelocity = 0; // Initial velocity of the block
    private final int GRAVITY = 1; // Gravity effect on the block
    private final int JUMP_STRENGTH = -15; // Jump strength
    private Timer timer;
    int a=0;
    int n=10;
    Rectangle bird = new Rectangle(10,birdY,50,50 );
    Rectangle blocks[] = new Rectangle[n];
    Image objects[]=new Image[n];
    int speed[]=new int[n];
    boolean jump=false;
    boolean start=false;
    boolean gameOver=false;
    String endMess="GAME OVER";
    int mx=120;
    int score=0;
    int level=1;
    String bg[]={"asset\\bg7.jpg",
    		"asset\\bg1.jpg",
    		"asset\\bg2.jpg",
    		"asset\\bg3.jpg",
    		"asset\\bg4.jpg",
    		"asset\\bg5.jpg",
    		"asset\\bg6.jpg",};
    int index=0;
    boolean choose=false;
    
    public game() {
    	defineBlocks();
        timer = new Timer(5, this);  
        addKeyListener(this);
        setFocusable(true);
        timer.start();;
        setFocusTraversalKeysEnabled(false);
        setString(); 
    }

	public void setString() {
		
	}

	private void defineBlocks() {
    	birdY = 250;
    	Random r= new Random();
    	blocks = new Rectangle[n];
    	objects=new Image[n];
    	speed=new int[n];
		 Image obj1=Toolkit.getDefaultToolkit().getImage("asset\\plane2.png");
	     Image obj2=Toolkit.getDefaultToolkit().getImage("asset\\ufo2.png");
	     Image obj3=Toolkit.getDefaultToolkit().getImage("asset\\missile1.png");
	     Image obj4=Toolkit.getDefaultToolkit().getImage("asset\\cloud3.png");
	     Image obj5=Toolkit.getDefaultToolkit().getImage("asset\\cloud4.png");
		 for(int i=0;i<blocks.length;i++) {
			 speed[i]=r.nextInt(1)+2;
			 blocks[i]=new Rectangle(0,0,0,0);
			 if(i==0) {
				blocks[i].x=500; 
			 }
			 else {
				 blocks[i].x=r.nextInt(400)+blocks[i-1].x+500 ;
			 }
			 int y=r.nextInt(frame.getHeight())-100;
			 if(y>10) {
				 blocks[i].y=y;
			 }
			 else {
				 blocks[i].y=10;
			 }
			 blocks[i].width=175;
			 blocks[i].height=100;
			 int j=r.nextInt(5);
			 if(j==0)
				 objects[i]=obj1;
			 if(j==1)
				 objects[i]=obj5;
			 if(j==2)
				 objects[i]=obj2;
			 if(j==3)
				 objects[i]=obj3;
			 if(j==4)
				 objects[i]=obj4;
		 }
	}

	@Override
	public void paint(Graphics g) {
        super.paint(g);
        draw(g);      
    }

    private void draw(Graphics g) {
		// TODO Auto-generated method stub
    	Image background=Toolkit.getDefaultToolkit().getImage(bg[index]);
        for(int i=0; i<100;i++) {
        	 g.drawImage(background, a+(i*background.getWidth(this)), 0, background.getWidth(this), frame.getHeight()-39, frame);
        }

        Image b1=Toolkit.getDefaultToolkit().getImage("asset\\b1.png");
        Image b2=Toolkit.getDefaultToolkit().getImage("asset\\b2.png");
        if(jump)
        	g.drawImage(b1,bird.x, birdY, bird.width, bird.height,frame);
        else
        	g.drawImage(b2,bird.x, birdY, bird.width, bird.height,frame);
		for(int i=0;i<blocks.length;i++) {
		   g.drawImage(objects[i], blocks[i].x, blocks[i].y,blocks[i].width, blocks[i].height, frame);
		}
		if(!start) {
			g.setColor(Color.RED);
			g.setFont(new Font("Impact",50,50));
			g.drawString("START", frame.getWidth()/2-80 ,frame.getHeight()/2);
		}
		if(gameOver) {
			g.setColor(Color.RED);
			g.setFont(new Font("Impact",50,50));
			g.drawString(endMess, mx, frame.getHeight()/2);
		}
		g.setColor(Color.RED);
		g.setFont(new Font("Impact",25,25));
		g.drawString("score : "+score+"    " + " level : "+level , 10 ,30);
	}

	@Override
    public void actionPerformed(ActionEvent e) {
    	if(start)
    		doAllshit();
        
        frame.repaint();
    }

    private void doAllshit() {
		// TODO Auto-generated method stub
    	blockVelocity += GRAVITY; // Apply gravity to the block's velocity
        birdY += blockVelocity; // Update block's position

        if (birdY > getHeight() - 50) {
        	timer.stop();
        	gameOver=true;
        	endMess="BIRD FELL";
        	mx=(frame.getWidth()/2)-120;;
        
        }
        if (birdY < 0) {
        	birdY = 0; // Prevent block from going above the screen
            blockVelocity = 0;
        }
        a--;
        for(int i=0;i<blocks.length;i++) {
        	blocks[i].x=blocks[i].x-speed[i];
        	
        	if(bird.intersects(blocks[i])) {
        		timer.stop();
        		endMess="BIRD CRASH";
        		gameOver=true;
        		mx=(frame.getWidth()/2)-150;;
        	}
        	if(blocks[i].x<-200) {
        		score=score+1;
        		speed[i]=0;;
        		blocks[i].x=10000;
        	}
		}
        if(score>blocks.length) {
        	n=n+10;
        	score=0;
        	level++;
        	defineBlocks();
        	timer.stop();
    		endMess="NEXT LEVEL";
    		gameOver=true;
    		mx=(frame.getWidth()/2)-150;;
        }
        bird = new Rectangle(10,birdY,50,50);
	}

	public static void main(String[] args) {
    	frame.setSize(516, 739);	//	16 , 39 offset error
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	game gamePanel = new game();
        frame.add(gamePanel);
        frame.setVisible(true);
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage("asset/b2.png"));
    }

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
	    if (e.getKeyCode() == KeyEvent.VK_SPACE) {
	    	blockVelocity = JUMP_STRENGTH;
	    	jump=true;
	    }
	    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
	    	if(start==false || gameOver) {
	    		System.out.println("ENTER PRESS");
	    		timer.start();
	    		jump=true;	
	    		start=true;
	    		blockVelocity = JUMP_STRENGTH;
	    		gameOver=false; 
	    		defineBlocks();
	    	}
	    }
	    if(e.getKeyCode()==KeyEvent.VK_TAB) {
	    	index++;
	    	if(index==bg.length-1) {
	    		index=0;
	    	}
	    }
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {    	
	    	jump=false;	
	    } 
	}

	
}